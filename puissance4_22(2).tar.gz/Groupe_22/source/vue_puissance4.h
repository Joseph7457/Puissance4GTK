#ifndef __VP4__
#define __VP4__

#include "modele_puissance4.h"
#include <stdlib.h>
#include <gtk/gtk.h>

#define img_0  "./images/vide.gif"
#define img_1  "./images/jjaune.gif"
#define img_2  "./images/jrouge.gif"
#define img_3  "./images/a.gif"

typedef struct vue_p4
{
  ModelePuissance4* mp4;
  GtkWidget***      plateau;
  GtkWidget**       boiteHorizontale;
  GtkWidget*        pFenetre;

}VuePuissance4;


/**
 * \fn VuePuissance4* creer_vue_puissance4(ModelePuissance4* mp4, GtkWidget *fenetre)
 * \param *mp4 : le modele du jeu
 * \param *fenetre : la fenetre du jeu
 * \brief Créé la vue du jeu
 * \return La vue du jeu
 */
VuePuissance4* creer_vue_puissance4(ModelePuissance4* mp4, GtkWidget *fenetre);


/**
 * \fn void changer_image(VuePuissance4* vp4, int l, int c, char* img);
 * \param *vp4 : la vue du jeu
 * \param l : le nomble de lignes
 * \param c : le nonmbre de colonnes
 * \param *img : le nom d'une image choisie
 * \brief Modifie une image dans le plateau du jeu
 * \result L'image a été modifié
 */
void changer_image(VuePuissance4* vp4, int l, int c, char* img);


/**
 * \fn void actualiser_images_a_zero(VuePuissance4* vp4, int lig, int col);
 * \param *vp4 : la vue du jeu
 * \param lig : le nomble de lignes
 * \param col : le nonmbre de colonnes
 * \brief Remet les images initiales du plateau
 * \result Le plateau est remis à zéro. 
 */
void actualiser_images_a_zero(VuePuissance4* vp4, int lig, int col);




#endif
