#ifndef __UTILS__
#define __UTILS__
#include "controleur_puissance4.h"


typedef struct joueur_j{
char nom[50];
char score_texte[20] ;
int  score;
int  nombre_joueur;
}Joueur;

/**
 * \fn GtkButton *bouton_avec_image(char* image);
 * \param *image : l'image à ajouter dans le bouton
 * \brief Créz un bouton avec une image dedans
 * \return Un bouton avec une image
 */
GtkButton *bouton_avec_image(char* image);

/**
 * \fn void changer_image_bouton(GtkWidget *bouton, char* image);
 * \param *bouton : le bouton à modifier
 * \param *image : l'image à ajouter dans le bouton
 * \brief Modifie l'image dans le bouton par une autre
 * \result L'image du bouton a été modifiée
 */
void changer_image_bouton(GtkWidget *bouton, char* image);


/**
 * \fn void detruire_fenetre(GtkWidget *pF, gpointer data);
 * \param *pF : la fenetre à détruire
 * \brief Détruit une fenêtre
 * \result La fenêtre pF est détruite et le programme est coupé
 */
void detruire_fenetre(GtkWidget *pF, gpointer data);

/**
 * \fn void detruire_fenetre_annexe(GtkWidget *pF, gpointer data);
 * \param *pF : la fenetre à détruire
 * \brief Détruit une fenêtre
 * \result La fenêtre pF est détruite
 */
void detruire_fenetre_annexe(GtkWidget* bouton, gpointer data);

/**
 * \fn void detruire_fenetre_annexe(GtkWidget *pF, gpointer data);
 * \brief Obsolète
 */
void choisir_nouvelle_image(GtkWidget *img, char* image);

/**
 * \fn int nombre_aligne(int** plateau, int l, int c, int pl, int pc, int critArr);
 * \param plateau : le plateau de jeu
 * \param l : nombre de lignes du plateau
 * \param c : nombre de colonnes du plateau
 * \param pl : la ligne sur laquelle est la pièce qui est inspectée.
 * \param pc : la colonne sur laquelle est la pièce qui est inspectée.
 * \param critArr : nombre de pieces alignées sufisantes pour quitter la fonction.
 * \brief Retourne le nombre maximum de pièces alignées du même type à la position donnée
 * \return le nombre de pièces identiques alignées
 */
int nombre_aligne(int** plateau, int l, int c, int pl, int pc, int critArr);


/**
 * \fn GtkWidget *choisir_image(char* image);
 * \param image : une image
 * \brief Charge une image
 * \return Un widget avec image
 */
GtkWidget *choisir_image(char* image);


/**
 * \fn GtkWidget *choisir_autre_image(char* image, GtkWidget* img);
 * \param image : une image
 * \param img : une autre image
 * \brief Remplace une image par une autre
 * \return image a été remplacé par img
 */

GtkWidget *choisir_autre_image(char* image, GtkWidget* img);


/**
 * \fn GtkWidget *creer_fenetre_principale();
 * \brief Créé la fenêtre principale du jeu
 * \return La fenêtre principale du jeu
 */
GtkWidget *creer_fenetre_principale();



/**
 * \fn void  charger_joueur(char* fichier, Joueur* liste_j, int nombre_joueur);
 * \param fichier : le fichier contenant les joueurs
 * \param liste_j : la liste les joueurs
 * \param nombre_joueur : le nombre de joueurs
 * \brief Charge les joueurs contenus dans le fichiers
 * \result Les joueurs sont chargés
 */
void  charger_joueur(char* fichier, Joueur* liste_j, int nombre_joueur);

/**
 * \fn int obtenir_nombre_joueur(char* fichier);
 * \param fichier : le fichier contenant les joueurs
 * \brief Compte le nombre de joueurs dans le fichier
 * \return Le nombre de joueurs
 */
int obtenir_nombre_joueur(char* fichier);

/**
 * \fn int joueur_est_present(char* fichier, char* nom);
 * \param fichier : le fichier contenant les joueurs
 * \param nom : un nom
 * \brief Vérifie si le nom du joueur se trouve dans le fichier
 * \return Retourne 1 si le joueur est présent, -1 sinon
 */
int joueur_est_present(char* fichier, char* nom);

/**
 * \fn void ecrire_document(char* fichier, Joueur* liste_j);
 * \param fichier : un fichier
 * \param liste_j : la liste des joeurs
 * \brief Ecris le nom et le score de chaque joueur
 * \result Les joueurs ont été rajouté au fichier
 */
void ecrire_document(char* fichier, Joueur* liste_j);

/**
 * \fn void ajouter_joueur(char* fichier, char* nom, int score);
 * \param fichier : un fichier
 * \param nom : un nom de joueur
 * \param score : le score d'un joueur
 * \brief Ajoute le nom et le score d'un joueur au fichier
 * \result Le joueur a été ajouté au fichier
 */
void ajouter_joueur(char* fichier, char* nom, int score);

/**
 * \fn GtkWidget *creer_menu(void* cp4, Joueur* j);
 * \param cp4 : le controleur du jeu
 * \param liste_j : la liste des joueurs
 * \brief Créé un menu
 * \return Un menu
 */
GtkWidget *creer_menu(void* cp4, Joueur* j);


/**
 * \fn GtkWidget *creer_menu_aide();
 * \brief Créé la  barre de menu "Aide"
 * \return La barre de menu "Aide"
 */
GtkWidget *creer_menu_aide();

/**
 * \fn GtkWidget *creer_fenetre_apropos()
 * \brief Créé la fenêtre "A propos"
 * \return La fenêtre "A propos"
 */
GtkWidget *creer_fenetre_apropos();

/**
 * \fn void clic_fenetre_apropos(GtkWidget* bouton);
 * \param liste_j : la liste les joueurs
 * \brief Affiche la fenetre "A propos"
 * \result La fenetre "A propos" est affichée
 */
void clic_fenetre_apropos(GtkWidget* bouton);

/**
 * \fn GtkWidget *creer_menu_partie(void* cp4, Joueur* j);
 * \param cp4 : le controleur du jeu
 * \brief Créé la barre de menu "Partie"
 * \return La barre de menu "Partie"
 */
GtkWidget *creer_menu_partie(void* cp4, Joueur* j);

/**
 * \fn GtkWidget *creer_fenetre_scores(Joueur* liste_j)
 * \param liste_j : la liste les joueurs
 * \brief Créé la fenêtre "Meilleurs scores"
 * \return La fenêtre "Meilleurs scores"
 */
GtkWidget *creer_fenetre_scores(Joueur* liste_j);

/**
 * \fn void clic_fenetre_score(GtkWidget* bouton);
 * \param liste_j : la liste les joueurs
 * \brief Affiche la fenetre "Meilleurs scores"
 * \result La fenetre "Meilleurs scores" est affichée
 */
void clic_fenetre_score(GtkWidget* bouton, gpointer data);



#endif

