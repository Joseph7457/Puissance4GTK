#include "modele_puissance4.h"
#include "vue_puissance4.h"
#include "utils.h"
#include <stdlib.h>
#include <gtk/gtk.h>
#include <stdio.h>
#include <unistd.h>

VuePuissance4* creer_vue_puissance4(ModelePuissance4* mp4, GtkWidget *fenetre)
{
  VuePuissance4 *vp4 = malloc(sizeof(VuePuissance4));

  if (vp4 == NULL)
    return NULL;

  vp4->pFenetre = fenetre;
  vp4->mp4 = mp4;

  vp4->boiteHorizontale = malloc(sizeof(GtkWidget) * mp4->lignes);
  for(int l = 0; l<mp4->lignes; l++)
  {
    vp4->boiteHorizontale[l] = gtk_hbox_new(TRUE, 0);
  }

  vp4->plateau    = malloc(sizeof(GtkWidget)*mp4->lignes);
  for (int i = 0; i<mp4->lignes; i++)
  {
    vp4->plateau[i] = malloc(sizeof(GtkWidget)*mp4->colonnes);
  }


  for (int l = 0; l<mp4->lignes; l++)
  {
    for (int c = 0; c<mp4->colonnes; c++)
    {
      vp4->plateau[l][c] = choisir_image(img_0);
    }
  }

  return vp4;
}


void changer_image(VuePuissance4* vp4, int l, int c, char* img)
{
   choisir_autre_image(img, vp4->plateau[l][c]);
   while (gtk_events_pending ())
 	    gtk_main_iteration ();
}


void actualiser_images_a_zero(VuePuissance4* vp4, int lig, int col)
{
	for (int l = 0; l < lig; l++)
		for (int c = 0; c < col; c++)
			   choisir_autre_image(img_0, vp4->plateau[l][c]);

}
