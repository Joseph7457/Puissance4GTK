#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
#include <assert.h>
#include "modele_puissance4.h"
#include "utils.h"




ModelePuissance4* creer_modele_puissance4(int lignes, int colonnes)
{
  ModelePuissance4* mp4 = malloc(sizeof(ModelePuissance4));
  if(mp4 == NULL)
    exit(1);

  mp4->lignes   = lignes;
  mp4->colonnes = colonnes;
  mp4->plateau  = creer_modele_plateau(lignes, colonnes);
  mp4->plateau_simule = creer_modele_plateau(lignes, colonnes);

  vider(mp4);
  return mp4;
}


int** creer_modele_plateau(int lignes, int colonnes)
{
  int** plateau = (int**) malloc(sizeof(int*) * lignes);

  for (int l = 0 ; l < lignes; l++)
  {
      plateau[l] = (int*) malloc(sizeof(int) * colonnes);
  }
return plateau;
}

//retourne la valeur du coup
int simuler_coup(ModelePuissance4* mp4, int joueur, int col)
{
  for (int l = 0; l < mp4->lignes; l++)
  {
    for (int c = 0; c < mp4->colonnes; c++)
    {
      mp4->plateau_simule[l][c] = mp4->plateau[l][c];
    }
  }

  int lig  = 1;
  while(lig < mp4->lignes && mp4->plateau_simule[lig][col] == 0 )
  {
    lig++;
  }
  lig--;

  mp4->plateau_simule[lig][col] = joueur;

  return nombre_aligne(mp4->plateau_simule, mp4->lignes, mp4->colonnes, lig, col, 4);
}


void changer_case(ModelePuissance4* mp4, int l, int c, int v)
{
  mp4->plateau[l][c] = v;
}

void vider(ModelePuissance4* mp4)
{
  printf("%d %d\n", mp4->lignes, mp4->colonnes);

  for (int l = 0 ; l < mp4->lignes; l++)
  {
      printf("l = %d\n", l);
      for (int c = 0 ; c < mp4->colonnes; c++)
      {
          mp4->plateau[l][c] = 0;
          printf("c = %d\n", c);
      }
  }
  printf("Les cases sont à zéro\n");
}
