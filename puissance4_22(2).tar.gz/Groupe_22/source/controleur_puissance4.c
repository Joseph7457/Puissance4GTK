#include <stdlib.h>
#include <gtk/gtk.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>
#include "vue_puissance4.h"
#include "controleur_puissance4.h"
#include "modele_puissance4.h"
#include "utils.h"
#include <unistd.h>
#include <time.h>


ControleurPuissance4* creer_controleur_puissance_4(ModelePuissance4* mp4, VuePuissance4* vp4, int score)
{
  assert(mp4 && vp4);

  ControleurPuissance4* cp4 = malloc(sizeof(ControleurPuissance4));
  cp4->score = score;
  cp4->mp4 = mp4;
  cp4->vp4 = vp4;
  cp4->tourJoueur = 1;
  cp4->piecePosee = 0;
  cp4->boiteHorizontale = gtk_hbox_new(TRUE, 0);

  cp4->boutons = malloc(sizeof(GtkWidget)*mp4->colonnes);

  for (int i = 0; i < cp4->mp4->colonnes; i++)
  {
    cp4->boutons[i] = bouton_avec_image(img_3);
    g_signal_connect(G_OBJECT(cp4->boutons[i]), "clicked", G_CALLBACK(clic_bouton), cp4);

    //gtk_box_pack_start(GTK_BOX(cp4->boiteHorizontale), cp4->boutons[i], TRUE, TRUE, 0);
  }

  return cp4;
}

int retourner_colonne(ControleurPuissance4* cp4, GtkWidget* bouton)
{
  for (int i = 0; i < cp4->mp4->colonnes; i++)
  {
    if(cp4->boutons[i] == bouton)
      return i;
  }
  return -1;
}

void clic_bouton(GtkWidget* bouton, gpointer data)
{
  ControleurPuissance4* cp4 = (ControleurPuissance4*) data;

  int index = retourner_colonne(cp4, bouton);

  if(cp4->tourJoueur == 1 && cp4->piecePosee == 0 && cp4->mp4->plateau[0][index] == 0)
  {
    changer_sensibilite_boutons(cp4, FALSE);
    descendre_colonnes(cp4, index, 0);
  }
}

void descendre_colonnes(ControleurPuissance4* cp4, int colonnes, int position)
{
  if(position == 0)
  {
    if(cp4->tourJoueur == 1)
    {
      cp4->mp4->plateau[position][colonnes] = 1;
      changer_image(cp4->vp4, position, colonnes, img_1);
    }
    else if(cp4->tourJoueur == 2)
    {
      cp4->mp4->plateau[position][colonnes] = 2;
      changer_image(cp4->vp4, position, colonnes, img_2);
    }
    usleep(100000);
    descendre_colonnes(cp4, colonnes, position+1);
  }

  else if
  (position > 0 &&  position < cp4->mp4->lignes && cp4->mp4->plateau[position][colonnes] == 0)
  {
    if(cp4->tourJoueur == 1)
    {
      cp4->mp4->plateau[position-1][colonnes] = 0;
      cp4->mp4->plateau[position][colonnes] = 1;
      changer_image(cp4->vp4, position-1, colonnes, img_0);
      changer_image(cp4->vp4, position, colonnes, img_1);
    }
    else if(cp4->tourJoueur == 2)
    {
      cp4->mp4->plateau[position-1][colonnes] = 0;
      cp4->mp4->plateau[position][colonnes] = 2;
      changer_image(cp4->vp4, position-1, colonnes, img_0);
      changer_image(cp4->vp4, position, colonnes, img_2);
    }
    usleep(100000);
    descendre_colonnes(cp4, colonnes, position+1);
  }
  else
  {
    if(verifier_victoire(cp4, position-1, colonnes) == 1)
    {
      if(cp4->tourJoueur == 1)
      {
        printf("Victoire humaine +1 :D\n");
        cp4->score++;
      }
      else
      {
        printf("Victoire Machine, you got -1 :D\n");
        cp4->score--;
      }
      cp4->tourJoueur = 0;

    }

    if (cp4->tourJoueur == 1)
      {
        cp4->piecePosee = 0;
        cp4->tourJoueur = 2;
        tour_adversaire(cp4);
      }
  else if(cp4->tourJoueur == 2)
      {
        cp4->tourJoueur = 1;
        cp4->piecePosee = 0;
        changer_sensibilite_boutons(cp4, TRUE);
      }


  }
}

void changer_sensibilite_boutons(ControleurPuissance4* cp4, int statut)
{
  for (int i = 0; i < cp4->mp4->colonnes; i++)
  {
    if (statut == 0)
      gtk_widget_set_sensitive(cp4->boutons[i] , FALSE );
    else
      gtk_widget_set_sensitive(cp4->boutons[i] , TRUE );
  }

}



int verifier_victoire(ControleurPuissance4* cp4, int l, int c)
{
  int chaineMax = nombre_aligne(cp4->mp4->plateau, cp4->mp4->lignes, cp4->mp4->colonnes, l, c, 4);

  if( chaineMax >= 4)
    return 1;
  else
    return 0;
}



void tour_adversaire(ControleurPuissance4 *cp4)
{
int meilleur_coup_ORDI[]   = {0,0}; // points
int c_meilleur_coup_ORDI[] = {0,0}; // colonne
int meilleur_coup_J1[]     = {0,0}; // points
int c_meilleur_coup_J1[]   = {0,0}; // colonnes

for (int  c = 0; c < cp4->mp4->colonnes; c++)
 {
   int points = 0;

   /* simulation des coups possibles pour l'ordinateur */
   if(cp4->mp4->plateau[0][c] == 0)
    {
      points = simuler_coup(cp4->mp4, 2, c);
    }

   if(points > meilleur_coup_ORDI[0])
   {
     meilleur_coup_ORDI[1]   = meilleur_coup_ORDI[0];
     c_meilleur_coup_ORDI[1] = c_meilleur_coup_ORDI[0];

     meilleur_coup_ORDI[0]   = points;
     c_meilleur_coup_ORDI[0] = c;
   }
   else if(points > meilleur_coup_ORDI[1])
   {
     meilleur_coup_ORDI[1]   = points;
     c_meilleur_coup_ORDI[1] = c;
   }

   /* simulation des prochains coups possibles pour le */
   if(cp4->mp4->plateau[0][c] == 0)
    {
      points = simuler_coup(cp4->mp4, 1, c);
    }

   if(points > meilleur_coup_J1[0])
   {
     meilleur_coup_J1[1]   = meilleur_coup_J1[0];
     c_meilleur_coup_J1[1] = c_meilleur_coup_J1[0];

     meilleur_coup_J1[0]   = points;
     c_meilleur_coup_J1[0] = c;
   }
   else if(points > meilleur_coup_J1[1])
   {
     meilleur_coup_J1[1]   = points;
     c_meilleur_coup_J1[1] = c;
   }

 }

printf("Points: %d, %d\n", meilleur_coup_ORDI[0], meilleur_coup_J1[1]);
if(meilleur_coup_ORDI[0] >= 4)
{
  descendre_colonnes(cp4, c_meilleur_coup_ORDI[0], 0);
}
else if(meilleur_coup_J1[0] >= 4)
{
  descendre_colonnes(cp4, c_meilleur_coup_J1[0], 0);
}
else if(meilleur_coup_ORDI[0] >= 3)
{
  descendre_colonnes(cp4, c_meilleur_coup_J1[0], 0);
}
else if(meilleur_coup_J1[0] >= 3)
{
  descendre_colonnes(cp4, c_meilleur_coup_J1[0], 0);
}
else
{
int temp[] = { c_meilleur_coup_J1[0], c_meilleur_coup_J1[1],
               c_meilleur_coup_ORDI[0], c_meilleur_coup_ORDI[1]};
srand(time(NULL));   // Initialization, should only be called once.
int random = rand()%5;
printf("Random = %d\n\n", random);
descendre_colonnes(cp4, temp[random], 0);

}

}


void clic_nouvelle_partie(GtkWidget* bouton, gpointer data)
{
   ControleurPuissance4* cp4 = (ControleurPuissance4*) data;
   vider(cp4->mp4);
   actualiser_images_a_zero(cp4->vp4, cp4->mp4->lignes, cp4->mp4->colonnes);
   changer_sensibilite_boutons(cp4, TRUE);
   cp4->tourJoueur = 1;
}
