#ifndef __MP4__
#define __MP4__

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>

typedef struct modele_p4
{
  int lignes;
  int colonnes;
  int** plateau;
  int** plateau_simule;
}ModelePuissance4;


/**
 * \fn ModelePuissance4 creer_modele_puissance4(int lignes, int colonnes)
 * \param lignes : le nombre de ligne du jeu
 * \param colonnes : le nonmbre de colonnes du jeu
 * \brief Créé un model puissance4
 * \return Un model de puissance4
 */
ModelePuissance4* creer_modele_puissance4(int lignes, int colonnes);


/**
 * \fn int** creer_modele_plateau(int lignes, int colonnes)
 * \param lignes le nombre de ligne du plateau
 * \param colonnes le nonmbre de colonnes du plateau
 * \brief Initialise un plateau de jeu
 * \return Un plateau de jeu
 */
int** creer_modele_plateau(int lignes, int colonnes);


/**
 * \fn void vider(ModelePuissance4* mp4)
 * \param mp4 : le pleateau du jeu
 * \brief : Réinitialise le plateau
 * \result : Le plateau est remis a zéro
 */
void vider(ModelePuissance4* mp4);


/**
 * \fn changer_case(ModelePuissance4* mp4, int l, int c, int v)
 * \param *mp4 Le controleur qui controle les coffres à fermer.
 * \param l : la ligne du plateau
 * \param c : la colonne du plateau
 * \param v : la valeur a ajouter dans la case
 * \brief Change la valeur d'une case
 * \result La valeur d'une case à été modifié
 */
void changer_case(ModelePuissance4* mp4, int l, int c, int v);


/**
 * \fn int simuler_coup(ModelePuissance4* mp4, int joueur, int c)
 * \param *mp4 : le pleateau du jeu
 * \param joueur : le joueur actuel
 * \param col : la colonne choisie pour ajouter la pièce
 * \brief Simule un coup et vérifie le nombre de pièces alignées
 * \return Le nombre de pièces alignées du joueur actuel
 */
int simuler_coup(ModelePuissance4* mp4, int joueur, int c);


#endif
