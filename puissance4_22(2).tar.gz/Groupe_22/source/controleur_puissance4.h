#ifndef __CP4__
#define __CP4__

#include <stdlib.h>
#include <gtk/gtk.h>
#include <string.h>
#include <assert.h>
#include "vue_puissance4.h"
#include "modele_puissance4.h"
#include "utils.h"

typedef struct controleur_p
{
int*            score;
ModelePuissance4* mp4;
VuePuissance4*    vp4;
GtkWidget**   boutons;
GtkWidget*    boiteHorizontale;
int           tourJoueur;
int           piecePosee;
}ControleurPuissance4;


/**
 * \fn ControleurPuissance4* creer_controleur_puissance_4(ModelePuissance4* mp4, VuePuissance4* vp4)
 * \param *mp4 : le modele du jeu
 * \param *vp4 : la vue du jeu
 * \brief Créé le controleur du jeu
 * \return le controleur du jeu
 */
ControleurPuissance4* creer_controleur_puissance_4(ModelePuissance4* mp4, VuePuissance4* vp4, int score);


/**
 * \fn int retourner_colonne(ControleurPuissance4* cp4, GtkWidget* bouton)
 * \param *cp4 : le controleur du jeu
 * \param *bouton : le bouton sur lequel je joueur a cliqué pour choisir une colonne
 * \brief Renvoie la colonne choisie
 * \return Le numéro de la colonne choisie
 */
int retourner_colonne(ControleurPuissance4* cp4, GtkWidget* bouton);


/**
 * \fn void clic_bouton(GtkWidget* bouton, gpointer data)
 * \param *bouton : le bouton sur lequel le joueur a cliqué pour choisir une colonne
 * \param data : l'adresse du controleur cp4
 * \brief Ajoute un pièce dans la colonne sélectionné par le bouton
 * \result Une pièce a été ajoutée
 */
void clic_bouton(GtkWidget* bouton, gpointer data);


/**
 * \fn void clic_nouvelle_partie(GtkWidget* bouton, gpointer data);
 * \param *bouton : le bouton pour lancer une nouvelle partie
 * \param data : l'adresse du controleur cp4
 * \brief Lance une nouvelle partie
 * \result Une nouvelle partie est lan   actualiser_images_a_zero(cp4->vp4, cp4->mp4->lignes,cée
 */
void clic_nouvelle_partie(GtkWidget* bouton, gpointer data);


/**
 * \fn descendre_colonnes(ControleurPuissance4* cp4, int colonnes, int position)
 * \param lignes : le nombre de ligne du jeu
 * \param colonnes : le nonmbre de colonnes du jeu
 * \brief Fait tombé une pièce étage par étagé
 * \result Une animation de pièce qui tombe
 */
void descendre_colonnes(ControleurPuissance4* cp4, int colonnes, int position);


/**
 * \fn void changer_sensibilite_boutons(ControleurPuissance4* cp4, int statut)
 * \param *cp4 : le controleur du jeu
 * \param statut : l'état du bouton
 * \brief Détermine si un bouton est clickable ou pas
 * \result Le bouton n'est pas cliquable si statut = 0, il est cliquable sinon
 */
void changer_sensibilite_boutons(ControleurPuissance4* cp4, int statut);


/**
 * \fn void tour_adversaire(ControleurPuissance4* cp4);
 * \param *cp4 : le controleur du jeu
 * \brief Simule tous les coups possible et stoke les deux meilleurs coups de chaque joueurs dans un tableau
 * \return Choisi le meilleur coup
 */
void tour_adversaire(ControleurPuissance4* cp4);


/**
 * \fn int verifier_victoire(ControleurPuissance4* cp4, int l, int c);
 * \param *cp4 : le controleur du jeu
 * \param l : le nomble de lignes
 * \param c : le nonmbre de colonnes
 * \brief Vérifie le jeu pour une suite victoirieuse
 * \return 1 si il y a une suite de 4 pièce, 0 sinon
 */
int verifier_victoire(ControleurPuissance4* cp4, int l, int c);

#endif
