#include <gtk/gtk.h>
#include <stdio.h>
#include "utils.h"
#include "modele_puissance4.h"
#include "vue_puissance4.h"
#include "controleur_puissance4.h"



GtkWidget *choisir_image(char* image)
{
  GdkPixbuf *pb_temp = gdk_pixbuf_new_from_file(image, NULL);
  if(pb_temp == NULL)
  {
    printf("erreur de chargement de l'image\n");
    return NULL;
  }
  GdkPixbuf *pb  = gdk_pixbuf_scale_simple(pb_temp, 75,75, GDK_INTERP_NEAREST);

  GtkWidget *img = gtk_image_new_from_pixbuf(pb);
  return img;
}

GtkWidget *choisir_autre_image(char* image, GtkWidget* img)
{
  GdkPixbuf *pb_temp = gdk_pixbuf_new_from_file(image, NULL);
  if(pb_temp == NULL)
  {
    return NULL;
  }
  GdkPixbuf *pb  = gdk_pixbuf_scale_simple(pb_temp, 75,75, GDK_INTERP_NEAREST);
  gtk_image_set_from_pixbuf(GTK_IMAGE(img), pb);
}



GtkButton *bouton_avec_image(char* image)
{
  GtkWidget *pBouton = gtk_button_new();

  GdkPixbuf *pb_temp = gdk_pixbuf_new_from_file(image, NULL);
  if(pb_temp == NULL)
  {
    return NULL;
  }
  GdkPixbuf *pb  = gdk_pixbuf_scale_simple(pb_temp, 50,50, GDK_INTERP_NEAREST);

  GtkWidget *img = gtk_image_new_from_pixbuf(pb);
  gtk_button_set_image(GTK_BUTTON(pBouton), img);
  return pBouton;
}

void changer_image_bouton(GtkWidget *bouton, char* image)
{
  GdkPixbuf *pb_temp = gdk_pixbuf_new_from_file(image, NULL);
  if(pb_temp == NULL)
  {
    exit(0);
  }
  GdkPixbuf *pb  = gdk_pixbuf_scale_simple(pb_temp, 50,50, GDK_INTERP_NEAREST);
  GtkWidget *img = gtk_image_new_from_pixbuf(pb);
  gtk_button_set_image(GTK_BUTTON(bouton), img);
}

void detruire_fenetre(GtkWidget *pF, gpointer data)
{
  gtk_main_quit();
}


int nombre_aligne(int** plateau, int l, int c, int pl, int pc, int critArr)
{
  int gauche = 1, droite = 1;
  int nombre = 1;
  int nombre_max = 0;


/* Cas Horizontal */
  for (int i = 1; i < critArr; i++)
  {
    int index = 0;
    if(gauche)
      {
        index = (pc-i);

        if ( index >= 0 && index < c && plateau[pl][pc] ==  plateau[pl][index])
          nombre++;
        else
          gauche = 0;

      }
    if(droite)
        {
          index = (pc+i);

          if ( index >= 0 && index < c && plateau[pl][pc] == plateau[pl][index])
            nombre++;
          else
            droite = 0;
        }
    }


  if(nombre > nombre_max )
    nombre_max = nombre;

  gauche = 1; droite = 1; nombre = 1;

  if(nombre_max >= critArr)
  {
    return nombre_max;
  }

  /* Cas Vertical */
  for (int i = 1; i < critArr; i++)
  {
    int index = 0;
    if(gauche)
      {
        index = (pl-i);
        if ( index >= 0 && index < l && plateau[pl][pc] ==  plateau[index][pc])
          nombre++;
        else
          gauche = 0;
      }

    if(droite)
        {
          index = (pl+i);
          if ( index >= 0 && index < l && plateau[pl][pc] ==  plateau[index][pc])
            nombre++;
          else
            droite = 0;
        }
  }



  if(nombre > nombre_max )
    nombre_max = nombre;

  gauche = 1; droite = 1; nombre = 1;

  if(nombre_max >= critArr)
  {
    return nombre_max;
  }

  /* Cas Diagonal Ascendante */
  for (int i = 1; i < critArr; i++)
  {
    int index  = 0;
    int index2 = 0;
    if(gauche)
      {
        index  = (pl-i);
        index2 = (pc+i);
        if ( index  >= 0 && index  < l
          && index2 >= 0 && index2 < c
          && plateau[pl][pc] ==  plateau[index][index2])
          nombre++;
        else
          gauche = 0;
      }

    if(droite)
        {
          index  = (pl+i);
          index2 = (pc-i);
          if ( index  >= 0 && index  < l
            && index2 >= 0 && index2 < c
            && plateau[pl][pc] ==  plateau[index][index2])
            nombre++;
          else
            droite = 0;
        }
  }


  if(nombre > nombre_max )
    nombre_max = nombre;

  gauche = 1; droite = 1; nombre = 1;

  if(nombre_max >= critArr)
  {
    return nombre_max;
  }


  /* Cas Diagonal Descendante */
  for (int i = 1; i < critArr; i++)
  {
    int index = 0;
    int index2 = 0;
    if(gauche)
      {
        index  = (pl-i);
        index2 = (pc-i);
        if ( index  >= 0 && index  < l
          && index2 >= 0 && index2 < c
          && plateau[pl][pc] ==  plateau[index][index2])
          nombre++;
        else
          gauche = 0;
      }

    if(droite)
        {
          index  = (pl+i);
          index2 = (pc+i);
          if ( index  >= 0 && index  < l
            && index2 >= 0 && index2 < c
            && plateau[pl][pc] ==  plateau[index][index2])
            nombre++;
          else
            droite = 0;
        }
  }

if(nombre > nombre_max )
    nombre_max = nombre;

return nombre_max;



}

/**************************************************************/


// creation de la fenetre principale :
GtkWidget *creer_fenetre_principale(){

  GtkWidget *pFP = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title(GTK_WINDOW(pFP), "Puissance 4");
  gtk_window_set_default_size(GTK_WINDOW(pFP), 600,600);

  g_signal_connect(G_OBJECT(pFP), "destroy", G_CALLBACK(gtk_main_quit), NULL);

  return pFP;
}





// creation de la fenêtre "Meilleurs scores" :
GtkWidget* creer_fenetre_scores(Joueur* j){


  GtkWidget *pFMS = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title(GTK_WINDOW(pFMS), "Meilleurs scores");
  gtk_window_set_default_size(GTK_WINDOW(pFMS), 350,350);
  g_signal_connect(G_OBJECT(pFMS), "destroy", G_CALLBACK(gtk_widget_destroy), pFMS);


  GtkWidget *vBox1;
  GtkWidget *vBox2;
  GtkWidget *hBox;
  GtkWidget *table_principal;
  GtkWidget *bouton_quitter ;
  GtkWidget *table_classement;
  GtkWidget *label_classement;


  vBox1 = gtk_vbox_new(FALSE, 0);
  vBox2 = gtk_vbox_new(FALSE, 0);
  hBox  = gtk_hbox_new(FALSE, 0);
  table_classement = gtk_table_new(2,2, FALSE);
  table_principal = gtk_table_new(3,3, FALSE);
  gtk_container_add(GTK_CONTAINER(pFMS), table_principal);


  int n = j[0].nombre_joueur;
  GtkWidget **pLabelN = malloc(sizeof(GtkWidget)*n);
  GtkWidget **pLabelS = malloc(sizeof(GtkWidget)*n);


  for (int l = 0; l<n; l++)
  {
    pLabelN[l] = gtk_label_new(j[l].nom);
    pLabelS[l] = gtk_label_new(j[l].score_texte);
    gtk_container_add(GTK_CONTAINER(vBox1), pLabelN[l]);
    gtk_container_add(GTK_CONTAINER(vBox2), pLabelS[l]);

  }

  label_classement = gtk_label_new("Ici sont inscrits les noms des plus grands joueurs!");
  gtk_table_attach(GTK_TABLE(table_principal), label_classement, 0,3,0,1, GTK_FILL,GTK_EXPAND | GTK_FILL,0,0);


  //gtk_container_add(GTK_CONTAINER(hBox), vBox1);
  //gtk_container_add(GTK_CONTAINER(hBox), vBox2);
  gtk_table_attach(GTK_TABLE(table_classement), vBox1, 0, 1, 0, 2, GTK_FILL, GTK_FILL, 10, 10);
  gtk_table_attach(GTK_TABLE(table_classement), vBox2, 1, 2, 0, 2, GTK_FILL, GTK_FILL, 10, 10);


  gtk_table_attach(GTK_TABLE(table_principal), table_classement, 0, 3, 1, 2, GTK_EXPAND , GTK_EXPAND | GTK_FILL , 1, 1);

  bouton_quitter = gtk_button_new_with_label("Quitter !");
  g_signal_connect(G_OBJECT(bouton_quitter), "clicked", G_CALLBACK(detruire_fenetre_annexe), pFMS);
  gtk_table_attach(GTK_TABLE(table_principal), bouton_quitter, 2, 3, 2, 3,  GTK_FILL,  GTK_FILL , 10, 10);

  return pFMS;
}

void detruire_fenetre_annexe(GtkWidget* bouton, gpointer data)
{
  GtkWidget* fenetre = (GtkWidget*) data;
  gtk_widget_destroy(fenetre);
}

void clic_fenetre_score(GtkWidget* bouton, gpointer data)
{

  Joueur* j = (Joueur*) data;

  if(j != NULL)
  {
    GtkWidget* fenetre_score = creer_fenetre_scores(j);
    gtk_widget_show_all(fenetre_score);
  }
}


// creation de la fenêtre "A propos" :
GtkWidget *creer_fenetre_apropos(){

  GtkWidget *table_principal;
  GtkWidget *label_apropos;
  GtkWidget *label_noms;
  GtkWidget *bouton_quitter;


  GtkWidget *pFAP = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title(GTK_WINDOW(pFAP), "A propos");
  gtk_window_set_default_size(GTK_WINDOW(pFAP), 350,350);

  table_principal = gtk_table_new(3,3, FALSE);
  gtk_container_add(GTK_CONTAINER(pFAP), table_principal);

  label_apropos = gtk_label_new("Puissance 4 -- Groupe 22");
  gtk_table_attach(GTK_TABLE(table_principal), label_apropos, 0, 3, 0, 1, GTK_EXPAND, GTK_FILL, 20, 20);

  label_noms = gtk_label_new("Joseph Gabirel -- Tolga Gunaydin");
  gtk_table_attach(GTK_TABLE(table_principal), label_noms, 0, 3, 1, 2, GTK_EXPAND, GTK_EXPAND | GTK_FILL, 0, 0);

  bouton_quitter = gtk_button_new_with_label("Quitter !");
  g_signal_connect(G_OBJECT(bouton_quitter), "clicked", G_CALLBACK(detruire_fenetre_annexe), pFAP);
  gtk_table_attach(GTK_TABLE(table_principal), bouton_quitter, 2, 3, 2, 3,  GTK_FILL,  GTK_FILL , 10, 10);


  g_signal_connect(G_OBJECT(pFAP), "destroy", G_CALLBACK(gtk_widget_destroy), NULL);


  return pFAP;
}

void clic_fenetre_apropos(GtkWidget* bouton)
{
  GtkWidget* fenetre_apropos = creer_fenetre_apropos();
  gtk_widget_show_all(fenetre_apropos);
}

// creation du menu "Partie" :
GtkWidget *creer_menu_partie(void* cp4, Joueur* j){
  GtkWidget *barre_menu_partie;
  GtkWidget *menu_partie;
  GtkWidget *item_partie;
  GtkWidget *item_nouvelle_partie;
  GtkWidget *item_meilleurs_scores;
  GtkWidget *item_quitter;


  //barres de menu :
  barre_menu_partie = gtk_menu_bar_new();


  //menus partie :
  menu_partie = gtk_menu_new();


  //creation des items :
  item_partie = gtk_menu_item_new_with_mnemonic("_Partie");
  item_nouvelle_partie = gtk_menu_item_new_with_mnemonic("_Nouvelle partie");
  item_meilleurs_scores = gtk_menu_item_new_with_mnemonic("_Meilleurs scores");
  item_quitter = gtk_menu_item_new_with_mnemonic("_Quitter");




  //attachement des items :
  gtk_menu_item_set_submenu(GTK_MENU_ITEM(item_partie), menu_partie);
  gtk_menu_shell_append(GTK_MENU_SHELL(menu_partie), item_nouvelle_partie);
  gtk_menu_shell_append(GTK_MENU_SHELL(menu_partie), item_meilleurs_scores);
  gtk_menu_shell_append(GTK_MENU_SHELL(menu_partie), item_quitter);
  gtk_menu_shell_append(GTK_MENU_SHELL(barre_menu_partie), item_partie);


  //signaux :
  g_signal_connect(G_OBJECT(item_nouvelle_partie), "activate", G_CALLBACK(clic_nouvelle_partie), cp4);
  g_signal_connect(G_OBJECT(item_meilleurs_scores), "activate", G_CALLBACK(clic_fenetre_score), j);
  g_signal_connect(G_OBJECT(item_quitter), "activate", G_CALLBACK(gtk_main_quit), NULL);

  return barre_menu_partie;
}//fin menu "Partie"


// creation du menu "Aide" :
GtkWidget *creer_menu_aide(){

  //déclaration des variables :
  GtkWidget *barre_menu_aide;
  GtkWidget *menu_aide;
  GtkWidget *item_aide;
  GtkWidget *item_a_propos;


  //barres de menu :
  barre_menu_aide = gtk_menu_bar_new();


  //menus partie et aide :
  menu_aide = gtk_menu_new();


  //creation des items :
  item_aide = gtk_menu_item_new_with_mnemonic("_Aide");
  item_a_propos = gtk_menu_item_new_with_mnemonic("_A propos");


  //attachement des items :
  gtk_menu_item_set_submenu(GTK_MENU_ITEM(item_aide), menu_aide);
  gtk_menu_shell_append(GTK_MENU_SHELL(menu_aide), item_a_propos);
  gtk_menu_shell_append(GTK_MENU_SHELL(barre_menu_aide), item_aide);

  //signaux :
  g_signal_connect(G_OBJECT(item_a_propos), "activate", G_CALLBACK(clic_fenetre_apropos), NULL);

  return barre_menu_aide;
}//fin menu "Aide"


//----------------------------------------------------------------//

GtkWidget* creer_menu(void* cp4, Joueur* liste_j)
{
GtkWidget* pMenu = gtk_hbox_new(FALSE, 0);
GtkWidget* pFenetreScores = creer_fenetre_scores(liste_j);
GtkWidget* pFenetreAPropos = creer_fenetre_apropos();
GtkWidget* pBarreMenuPartie = creer_menu_partie(cp4, liste_j);
GtkWidget* pBarreMenuAide = creer_menu_aide();

gtk_box_pack_start(GTK_BOX(pMenu), pBarreMenuPartie, FALSE, FALSE, 3);
gtk_box_pack_start(GTK_BOX(pMenu), pBarreMenuAide, FALSE, FALSE, 3);
return pMenu;
}


/*SAUVEGARDE*/

void charger_joueur(char* fichier, Joueur* liste_j, int nombre_joueur)
{

    FILE* fp = fopen(fichier, "r");
    if (!fp)
        return;

    char nom[50];
    char score[50];
    int nombre = 0;
    while(fscanf(fp, "%s %s", nom, score) == 2 && nombre < nombre_joueur)
    {
        strcpy(liste_j[nombre].score_texte, score);
        liste_j[nombre].score = atoi(score);
        strcpy( liste_j[nombre].nom , nom);
        liste_j[nombre].nombre_joueur = nombre_joueur;
        nombre++;
    }

    fclose(fp);
}


int obtenir_nombre_joueur(char* fichier)
{
  FILE* fp = fopen(fichier, "r");

  char nom[50];
  char score[50];
  int nombre = 0;
  if (!fp)
    return 0;


  while(fscanf(fp, "%s %s", nom, score) == 2)
  {
      nombre++;
  }

    fclose(fp);
    return nombre;
}




void ecrire_document(char* fichier, Joueur* liste_j)
{
    FILE* fp = fopen(fichier, "w+");
    for (int n = 0; n < liste_j[0].nombre_joueur; n++)
    {
       fprintf(fp, "%s %d\n", liste_j[n].nom, liste_j[n].score);
    }
    fclose(fp);
}

void ajouter_joueur(char* fichier, char* nom, int score)
{
    FILE* fp = fopen(fichier, "a");

    fprintf(fp, "%s %d\n", nom, score);
    fclose(fp);
}

int joueur_est_present(char* fichier, char* nom)
{
  int index = 0;
  FILE* fp = fopen(fichier, "r");
  char temp[50];
  char temp2[50];

  if (!fp)
    return 0;

    while(fscanf(fp, "%s %s", temp, temp2) == 2)
    {
      if(strcmp(nom, temp) == 0)
        return index;
      index++;
    }

  fclose(fp);
  return -1;
}

