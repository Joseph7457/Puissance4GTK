#include <stdlib.h>
#include <stdio.h>
#include <gtk/gtk.h>
#include <string.h>
#include "modele_puissance4.h"
#include "controleur_puissance4.h"
#include "vue_puissance4.h"
#include "utils.h"

#define img_g   "./images/g.gif"
#define img_d   "./images/d.gif"
#define img_b   "./images/b.gif"
#define img_cg  "./images/coing.gif"
#define img_cd  "./images/coind.gif"
#define img_n   "./images/noir.gif"

int main(int argc, char **argv){

// Prise des Arguments
/*
  — -n  : nom du joueur.
  — -l : nombre de lignes de la grille de jeu (6 par défaut).
  — -c : nombre de colonnes de la grille de jeu (7 par défaut).
  — -f : chemin vers le fichier maintenant les meilleurs scores.
  — -H : aide pour la ligne de commande.
*/

  char *optstring = ":n:l:c:f:H:";
  char val;
  int lignes   = 6;
  int colonnes = 7;
  char nom[200];
  strcpy(nom, "Anonyme");
  char fichier_charge[50];
  strcpy(fichier_charge, "save.txt");

   /* Prise des arguments       */
   while( (val = getopt(argc, argv, optstring)) != EOF)
   {
      switch(val)
      {
         case 'n':
         strcpy(nom, optarg)   ; break;
         case 'c':
         colonnes = atoi(optarg); break;
         case 'l':
         lignes = atoi(optarg); break;
         case 'f':
         strcpy(fichier_charge, optarg); break;
         case 'H':
         printf("-n Nom\n-c colonnes\n-l lignes\n-f fichier sauvegarder\n-H La meilleure des aides\n"); break;
         case '?':
         printf("Option inconnue : %c\n", optopt); break;
      }
   }


  /* Chargement de la sauvegarde*/

  int index_joueur = joueur_est_present(fichier_charge, nom);
  if( index_joueur == -1)
    {
      ajouter_joueur(fichier_charge, nom, 0);
      index_joueur = joueur_est_present(fichier_charge, nom);
    }
  int nombre_joueur =  obtenir_nombre_joueur(fichier_charge);
  Joueur* liste_j    = malloc(sizeof(Joueur) * nombre_joueur);
  charger_joueur(fichier_charge, liste_j, nombre_joueur);

  /*Création de l'interface Graphique"*/

  gtk_init(&argc, &argv);

  GtkWidget *pFenetre;
  pFenetre = creer_fenetre_principale();


  GtkWidget *pVBox   = gtk_vbox_new(TRUE, 0);
  GtkWidget *texte_0 = gtk_label_new("Plateau de jeu");


  ModelePuissance4*     mp4 = creer_modele_puissance4(lignes,colonnes);
  VuePuissance4*        vp4 = creer_vue_puissance4(mp4, pFenetre);
  ControleurPuissance4* cp4 = creer_controleur_puissance_4(mp4, vp4, liste_j[index_joueur].score);

  GtkWidget *menu = creer_menu(cp4, liste_j);

  pVBox = gtk_vbox_new(FALSE, 0);
  gtk_box_pack_start(GTK_BOX(pVBox), menu, FALSE, FALSE, 0);

  GtkWidget *pTable = gtk_table_new(lignes+3, colonnes+2, TRUE);

  GtkWidget** haut = malloc(sizeof(GtkWidget) * (colonnes+2));

  for (int c = 0; c<colonnes+2; c++)
  {
    haut[c] = choisir_image(img_n);
    gtk_table_attach(GTK_TABLE(pTable), haut[c], c, c+1, 0, 1, GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  }

  for (int l = 0; l<lignes; l++)
    for (int c = 0; c<colonnes; c++)
      gtk_table_attach(GTK_TABLE(pTable), vp4->plateau[l][c], c+1, c+2, l+1, l+2, GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);

  //for (int c = 0; c<colonnes; c++)
    //gtk_table_attach(GTK_TABLE(pVBox), cp4->boiteHorizontale, c, c+1, lignes, lignes+1, GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  /*
  for (int i = 0; i<lignes; i++)
    gtk_box_pack_start(GTK_BOX(pVBox), vp4->boiteHorizontale[i], FALSE, FALSE, 0);
*/
  gtk_box_pack_start(GTK_BOX(pVBox), pTable, FALSE, FALSE, 0);

  GtkWidget** bord_gauche = malloc(sizeof(GtkWidget) * (lignes));
  GtkWidget** bord_droit  = malloc(sizeof(GtkWidget) * (lignes));

  for (int l = 0; l < lignes; l++)
  {
    bord_gauche[l] = choisir_image(img_g);
    bord_droit[l]  = choisir_image(img_d);
    gtk_table_attach(GTK_TABLE(pTable), bord_gauche[l], 0, 1, l+1, l+2, GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
    gtk_table_attach(GTK_TABLE(pTable), bord_droit[l], colonnes+1, colonnes+2, l+1, l+2, GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  }

  GtkWidget** bord_bas    = malloc(sizeof(GtkWidget) * (colonnes));

  for (int c = 0; c < colonnes; c++)
  {
    bord_bas[c] = choisir_image(img_b);
    gtk_table_attach(GTK_TABLE(pTable), bord_bas[c], c+1, c+2, lignes+1, lignes+2, GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  }

  GtkWidget* coin_gauche = choisir_image(img_cg);
  gtk_table_attach(GTK_TABLE(pTable), coin_gauche, 0, 1, lignes+1, lignes+2, GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);

  GtkWidget* coin_droit  = choisir_image(img_cd);
  gtk_table_attach(GTK_TABLE(pTable), coin_droit, colonnes+1, colonnes+2, lignes+1, lignes+2, GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);

  //GtkWidget*  coin_gauche;


  for (int c = 0; c < colonnes; c++)
  gtk_table_attach(GTK_TABLE(pTable), cp4->boutons[c], c+1, c+2, lignes+2, lignes+3, GTK_EXPAND , GTK_EXPAND , 0, 0);

  GtkWidget* coin_inferieur_gauche = choisir_image(img_n);
  gtk_table_attach(GTK_TABLE(pTable), coin_inferieur_gauche, 0, 1, lignes+2, lignes+3, GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);

  GtkWidget* coin_inferieur_droit  = choisir_image(img_n);
  gtk_table_attach(GTK_TABLE(pTable), coin_inferieur_droit, colonnes+1, colonnes+2, lignes+2, lignes+3, GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);



  gtk_container_add(GTK_CONTAINER(pFenetre), pVBox);
  gtk_widget_show_all(pFenetre);
  gtk_main();

  liste_j[index_joueur].score = cp4->score;
  printf("Joueur : %s, points: %d\n", liste_j[index_joueur].nom, liste_j[index_joueur].score);
  ecrire_document(fichier_charge, liste_j);

  return EXIT_SUCCESS;

}//fin programme
